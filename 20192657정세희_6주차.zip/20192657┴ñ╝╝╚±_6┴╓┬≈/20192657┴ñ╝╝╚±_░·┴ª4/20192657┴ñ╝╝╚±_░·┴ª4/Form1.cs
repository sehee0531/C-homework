﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657정세희_과제4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(textBox1.Text);
                int b = int.Parse(textBox2.Text);

                if (a > b)
                {
                    label1.Text = "시작단수가 마지막단수보다 작거나 같아야 합니다";
                }
                else if (a < 2 || b > 9)
                {
                    label1.Text = "2에서 9사이의 수를 입력하세요";
                }
                else if (b < 2 || b > 9)
                {
                    label1.Text = "2에서 9사이의 수를 입력하세요";
                }
                else
                {
                    label1.Text = "구구단 " + a + "부터 " + b + "단까지 입니다!\n\n";
                    for (int i = a; i <= b; i++)
                    {
                        for (int j = 2; j <= 9; j++)
                        {
                            label1.Text += i + " * " + j + " = " + i * j + "\n";
                        }
                        label1.Text += "\n";
                    }
                }
            }
            catch (Exception ex)
            {
                label1.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
