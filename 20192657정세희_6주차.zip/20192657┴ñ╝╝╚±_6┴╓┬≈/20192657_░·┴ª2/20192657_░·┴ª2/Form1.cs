﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657_과제2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                uint udata01 = uint.Parse(textBox1.Text);
                if (udata01 < 2 || udata01 > 200)
                {
                    label1.Text = "2~200사이의 수를 입력하세요";
                    label2.Text = "";
                }
                else
                {
                    bool bdata = true;
                    string sdata = "";
                    int count = 0;
                    for (uint i = 2; i < udata01; i++)
                    {
                        for (uint j = 2; j < i; j++)
                        {
                            if (i % j == 0)
                            {
                                bdata = false;
                            }
                        }
                        if (bdata == true)
                        {
                            count++;
                            sdata += i.ToString() + ", ";
                            if (count % 10 == 0)
                            {
                            sdata = sdata + "\n";
                            }
                            
                        }
                        bdata = true;
                       
                    }
                    sdata = sdata.Trim();
                    sdata = sdata.Trim(',');
                    label2.Text = udata01 + "까지 발견된 소수는 다음과 같습니다.";
                    label1.Text = sdata;
                    
                }
            }
            catch(Exception ex)
            {
                label2.Text = ex.Message;
                label1.Text = "2~200사이의 수를 입력하세요";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
