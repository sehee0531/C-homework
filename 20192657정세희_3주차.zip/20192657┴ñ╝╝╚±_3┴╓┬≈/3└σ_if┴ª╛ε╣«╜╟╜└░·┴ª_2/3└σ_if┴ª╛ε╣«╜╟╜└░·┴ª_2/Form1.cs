﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3장_if제어문실습과제_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == "")
                {
                    textBox1.Text = "1 또는 2를 입력하세요!";
                }
                else if (textBox2.Text == "")
                {
                    textBox2.Text = "환산할 수를 입력하세요!";
                }
                else
                {
                    int a = int.Parse(textBox1.Text);
                    
                    if (a == 1)
                    {
                        double b = double.Parse(textBox2.Text)*3.28;
                        
                        textBox3.Text = b.ToString();
                        label5.Text = "feet";
                    }
                    else if (a == 2)
                    {
                        double b = double.Parse(textBox2.Text) / 3.28;
                        textBox3.Text = b.ToString();
                        label5.Text = "meter";
                    }
                    else
                    {
                        textBox1.Text = "1또는 2를 입력해주세요";
                    }
                }
            }
            catch
            {
                
                    textBox3.Text = "입력 문자열의 형식이 잘못되었습니다.";
                
            }

           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
