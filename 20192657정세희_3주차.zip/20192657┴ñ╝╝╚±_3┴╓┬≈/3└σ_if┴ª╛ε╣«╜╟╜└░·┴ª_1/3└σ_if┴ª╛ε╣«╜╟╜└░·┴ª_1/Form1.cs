﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3장_if제어문실습과제_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    textBox2.Text = "숫자를 입력하세요!";
                }
                else
                {

                    int a = int.Parse(textBox1.Text);
                    if (a < 0)
                    {
                        textBox2.Text = "0보다 작은 수를 입력했습니다!";
                    }
                    else if (a < 10)
                    {
                        textBox2.Text = "0과 10사이 수를 입력했습니다!";
                    }
                    else if (a < 50)
                    {
                        textBox2.Text = "10과 50사이 수를 입력했습니다!";
                    }
                    else if (a < 100)
                    {
                        textBox2.Text = "50과 100사이 수를 입력했습니다!";
                    }
                    else
                    {
                        textBox2.Text = "100이상의 수를 입력했습니다!";
                    }


                }
            }
            catch
            {


                textBox2.Text = "입력 문자열의 형식이 잘못되었습니다.";

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}



