﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3장_Switch실습과제04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    label1.Text = "숫자를 입력하세요!";
                }
                else
                {
                    int iData01 = int.Parse(textBox1.Text);
                    switch (iData01)
                    {
                        case 1:
                            label1.Text = "입력값 " + iData01 + " -> January";
                            break;
                        case 2:
                            label1.Text = "입력값 " + iData01 + " -> February";
                            break;
                        case 3:
                            label1.Text = "입력값 " + iData01 + " -> March";
                            break;
                        case 4:
                            label1.Text = "입력값 " + iData01 + " -> April";
                            break;
                        case 5:
                            label1.Text = "입력값 " + iData01 + " -> May";
                            break;
                        case 6:
                            label1.Text = "입력값 " + iData01 + " -> Jun";
                            break;
                        case 7:
                            label1.Text = "입력값 " + iData01 + " -> July";
                            break;
                        case 8:
                            label1.Text = "입력값 " + iData01 + " -> August";
                            break;
                        case 9:
                            label1.Text = "입력값 " + iData01 + " -> September";
                            break;
                        case 10:
                            label1.Text = "입력값 " + iData01 + " -> October";
                            break;
                        case 11:
                            label1.Text = "입력값 " + iData01 + " -> November";
                            break;
                        case 12:
                            label1.Text = "입력값 " + iData01 + " -> December";
                            break;
                        default:
                            label1.Text = "해당하는 Month가 없으니\n1~12 사이의 숫자를 입력하세요";
                            break;

                    }
                }
            }
            catch
            {
                label1.Text = "입력문자열의 형식이 잘못되었습니다";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
