﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657정세희_과제3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                bool bdata01 = true;
                uint udata01 = uint.Parse(textBox1.Text);

                for (int i = 2; i < udata01; i++)
                {
                    if (udata01 % i == 0)
                    {
                        bdata01=false;  
                    }
                }
                if(bdata01==true)
                {
                    label1.Text=udata01+"은 소수입니다!";
                }
                else{
                    label1.Text=udata01+"은 소수가 아닙니다!";
                }
            }
            catch(Exception ex)
            {
                label1.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
