﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int idata01 = int.Parse(textBox1.Text);
                string sdata01="";
                if (idata01 > 0 && idata01 < 21)
                {
                    for (int i = 1; i <= idata01; i++)
                    {
                        sdata01 = sdata01 + i.ToString() +", ";
                        if (i % 7 == 0)
                        {
                            sdata01 = sdata01 + "\n\n";
                        }
                    }
                    sdata01 = sdata01.Trim();//공백을 지움
                    sdata01 = sdata01.Trim(',');//콤마를 지움
                    label1.Text = sdata01;
                }
                else
                {
                    label1.Text = "1과 20사이의 수를 입력하세요";
                }
            }
            catch(Exception ex)
            {
                label1.Text = ex.Message;
            }
        }
    }
}
