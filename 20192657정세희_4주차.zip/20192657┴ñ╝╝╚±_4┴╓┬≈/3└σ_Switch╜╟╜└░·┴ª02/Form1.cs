﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3장_Switch실습과제02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if(textBox1.Text=="")
                {
                    label4.Text = "알파벳을 입력하세요";
                }
                else
                {
                    char cdata01 = char.Parse(textBox1.Text);//swith의 표현식은 char로
                    if (cdata01 >= 'a' && cdata01 <= 'z'|| cdata01>='A'&&cdata01<='z')
                    {
                        switch (cdata01)
                        {
                            case 'a'://char는 싱글코드로
                            case 'e':
                            case 'i':
                            case 'o':
                            case 'u':
                            case 'A'://char는 싱글코드로
                            case 'E':
                            case 'I':
                            case 'O':
                            case 'U':
                                label4.Text = cdata01 + " is vowel";
                                break;
                            default:
                                label4.Text = cdata01 + " is consonant";
                                break;
                        }
                    }
                    else
                    {
                        label4.Text =  "\""+cdata01+"\""+ " 을 입력하였습니다.\n영문 알파벳 한글자를 입력하세요!";
                    }
                }
            }
            catch
            {
                label4.Text = "문자열의 길이는 1자여야 합니다.";
            }
        }
    }
}
