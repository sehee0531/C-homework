﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657정세희_과제2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    label1.Text = "시작값을 입력하세요!";
                }
                else if (textBox2.Text == "")
                {
                    label1.Text = "마지막 값을 입력하세요!";
                }
                else
                {
                    ulong idata01 = ulong.Parse(textBox1.Text);
                    ulong idata02 = ulong.Parse(textBox2.Text);
                    if (idata01 > idata02||idata02==idata01)
                    {
                        label1.Text = "시작값은 마지막값보다 작은 값이어야 합니다!";
                    }
                    else if (idata02 > 20)
                    {
                        label1.Text = "마지막 값은 21보다 작은 값이어야 합니다!";
                    }
                    else
                    {
                        ulong sum = 0;
                        double sum2 = 1;
                        for (ulong i = idata01; i <= idata02; i++)
                        {
                            sum += i;
                            sum2 *= i;
                        }
                        label1.Text = idata01 + "부터" + idata02 + "까지의 합은" + sum + "\n곱은 " + sum2 + "입니다";
                    }
                }
            }
            catch(Exception ex)
            {
                label1.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
