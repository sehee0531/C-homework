﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20192657정세희_과제1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox1.Text == "")
                {
                    label1.Text = "최대값을 입력하세요";
                }
                else if (textBox2.Text == "")
                {
                    label1.Text = "증가값을 입력하세요";
                }
                else
                {
                    int a = int.Parse(textBox1.Text);
                    int b = int.Parse(textBox2.Text);
                    if (a < b)
                    {
                        label1.Text = "증가값은 최대값보다 작은 수를 입력하세요";
                    }
                    else
                    {
                        int sum = 0;
                        int mult = 1;
                        for (int i = 1; i <= a; i = i + b)
                        {
                            sum += i;
                            mult *= i;
                        }
                        label1.Text = "1부터 입력된 최대 값 :" + a + "까지  증가값 : " + b + "로 반복한 결과\n" +
                            "<<i의 더하기 합계 값 :" + sum.ToString() + ">>\n<<i 의 곱하기 합계 값 :" + mult.ToString() + ">>";

                    }
                }
            }

            catch(Exception ex)
            {
                label1.Text = ex.Message;
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "결과가 나오는 곳입니다";
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
